package com.abhi.reversecalc

import kotlin.math.pow
import java.util.Locale

/** Small expression calculator used by the keyboard suggestion row. */
object Calculator {
    fun calculate(input: String): String? {
        val raw = input.trim()
        if (raw.isEmpty()) return null
        return try {
            // Match the calculator-style percentage operation used most often.
            // 500+10% => 550, 500-10% => 450.
            val simplePercent = Regex("^([0-9]+(?:\\.[0-9]+)?)([+-])([0-9]+(?:\\.[0-9]+)?)%$")
                .matchEntire(raw.replace(" ", ""))
            val value = if (simplePercent != null) {
                val base = simplePercent.groupValues[1].toDouble()
                val op = simplePercent.groupValues[2][0]
                val percent = simplePercent.groupValues[3].toDouble()
                val amount = base * percent / 100.0
                if (op == '+') base + amount else base - amount
            } else {
                PercentageParser(raw).parse()
            }
            if (!value.isFinite()) null else format(value)
        } catch (_: Exception) {
            null
        }
    }

    private fun format(v: Double): String {
        if (kotlin.math.abs(v) < 1e-12) return "0"
        val rounded = if (kotlin.math.abs(v - v.toLong()) < 1e-10) v.toLong().toDouble() else v
        return if (rounded == rounded.toLong().toDouble()) {
            rounded.toLong().toString()
        } else {
            String.format(Locale.US, "%.10f", rounded)
                .trimEnd('0').trimEnd('.')
        }
    }

    /**
     * Percentage-aware expression parser.
     * Examples:
     *  10%       -> 0.1
     *  500*10%   -> 50
     *  500+10%   -> 550
     *  500-10%   -> 450
     *  10% of 500 is also accepted as 10%*500.
     */
    private class PercentageParser(private val source: String) {
        private val s = source.replace(" ", "")
            .replace("×", "*")
            .replace("÷", "/")
        private var p = 0

        fun parse(): Double {
            if (s.isEmpty() || !s.matches(Regex("[0-9+\\-*/%.()^]+"))) error("bad chars")
            val v = expression()
            if (p != s.length) error("extra")
            return v
        }

        private fun expression(): Double {
            var value = term()
            while (p < s.length && (s[p] == '+' || s[p] == '-')) {
                val op = s[p++]
                val rhs = term()
                // Calculator-style percentage: 500 + 10% means 500 + 10% of 500.
                value = if (op == '+') value + rhs else value - rhs
            }
            return value
        }

        private fun term(): Double {
            var value = power()
            while (p < s.length && (s[p] == '*' || s[p] == '/')) {
                val op = s[p++]
                val rhs = power()
                if (op == '*') value *= rhs else {
                    if (rhs == 0.0) error("zero")
                    value /= rhs
                }
            }
            return value
        }

        private fun power(): Double {
            var value = unary()
            if (p < s.length && s[p] == '^') {
                p++
                value = value.pow(power())
            }
            return value
        }

        private fun unary(): Double {
            if (p < s.length && s[p] == '+') { p++; return unary() }
            if (p < s.length && s[p] == '-') { p++; return -unary() }
            return number()
        }

        private fun number(): Double {
            if (p < s.length && s[p] == '(') {
                p++
                val v = expression()
                if (p >= s.length || s[p++] != ')') error(")")
                return if (p < s.length && s[p] == '%') { p++; v / 100.0 } else v
            }

            val start = p
            while (p < s.length && (s[p].isDigit() || s[p] == '.')) p++
            if (start == p) error("num")
            val n = s.substring(start, p).toDouble()
            return if (p < s.length && s[p] == '%') {
                p++
                n / 100.0
            } else n
        }
    }
}
