# Reverse Calc Keyboard v3
QWERTY Android IME with calculator suggestions, emoji-name suggestions, and whole-text reverse suggestion.
Example: `hello world` -> `dlrow olleh`.

The included GitHub Actions workflow builds a debug APK without a PC.
Upload the project to a GitHub repository, then run the **Build APK** workflow from Actions and download the generated artifact.
