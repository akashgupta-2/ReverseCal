# Toraco Key V5.4 HELLO STYLE + GBOARD ROW

QWERTY Android IME with calculator suggestions, emoji-name suggestions, and whole-text transformation modes.

Modes: Reverse, Mono, Double, Alt Case, H H, and hello-hheelllloo.

The mode selector is kept inside the suggestion bar; no PopupWindow is used, avoiding IME window-token crashes during mode switching.
