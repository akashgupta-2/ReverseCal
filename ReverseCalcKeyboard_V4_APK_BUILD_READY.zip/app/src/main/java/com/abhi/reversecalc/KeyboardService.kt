package com.abhi.reversecalc
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.View
import android.widget.*
class KeyboardService:InputMethodService(){
 private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
 private lateinit var root:LinearLayout
 private lateinit var suggestions:LinearLayout
 private var reverse=false
 private var symbols=false
 private var shift=false
 override fun onCreateInputView():View{
  root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(3),dp(3),dp(3),dp(3));setBackgroundColor(Color.rgb(235,235,235))}
  suggestions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
  root.addView(suggestions,LinearLayout.LayoutParams(-1,dp(40)))
  rebuild();update();return root
 }
 private fun rebuild(){
  while(root.childCount>1)root.removeViewAt(1)
  if(symbols){row("1234567890");row("@#$%&*()-+");row(".,!?/:;'\"")}else{row("qwertyuiop");row("asdfghjkl");row("zxcvbnm")}
  val b=LinearLayout(this)
  bottom(b,if(symbols)"ABC" else "123"){symbols=!symbols;rebuild();update()}
  bottom(b,"⇧"){shift=!shift;rebuild();update()}
  bottom(b,if(reverse)"REV" else "↔"){reverse=!reverse;update()}
  bottom(b,"SPACE",2.5f){commit(" ");update()}
  bottom(b,"⌫"){currentInputConnection.deleteSurroundingText(1,0);update()}
  bottom(b,"↵"){currentInputConnection.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN,66));currentInputConnection.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP,66));update()}
  root.addView(b,LinearLayout.LayoutParams(-1,dp(48)))
 }
 private fun row(chars:String){
  val r=LinearLayout(this)
  chars.forEach{c->val x=if(!symbols&&shift)c.uppercaseChar().toString() else c.toString();bottom(r,x){commit(x);update()}}
  root.addView(r,LinearLayout.LayoutParams(-1,dp(48)))
 }
 private fun bottom(r:LinearLayout,label:String,weight:Float=1f,action:()->Unit){
  val b=Button(this).apply{text=label;textSize=14f;isAllCaps=false;setPadding(2,0,2,0)
   background=GradientDrawable().apply{setColor(Color.WHITE);cornerRadius=8f}
   setOnClickListener{action()}}
  r.addView(b,LinearLayout.LayoutParams(0,dp(48),weight))
 }
 private fun commit(s:String){currentInputConnection.commitText(s,1)}
 private fun text()=currentInputConnection.getTextBeforeCursor(500,0)?.toString()?:""
 private fun token(s:String)=s.substringAfterLast(" ")
 private fun update(){
  if(!::suggestions.isInitialized)return
  suggestions.removeAllViews()
  val all=text();val tok=token(all)
  Calculator.calculate(tok)?.let{suggest(it)}
  EmojiData.search(tok).forEach{suggest(it.emoji)}
  if(reverse&&!all.isEmpty())suggest(all.reversed())
  if(suggestions.childCount==0){
   suggestions.addView(TextView(this).apply{text=if(reverse)"↔ Reverse: whole text" else "Type calculation or emoji name";textSize=13f;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(10),0,dp(10),0)})
  }
 }
 private fun suggest(v:String){
  val b=Button(this).apply{text=v;textSize=15f;isAllCaps=false;setPadding(dp(4),0,dp(4),0);setOnClickListener{
   val all=text();val tok=token(all);if(tok.isNotEmpty())currentInputConnection.deleteSurroundingText(tok.length,0);commit(v);update()
  }}
  suggestions.addView(b,LinearLayout.LayoutParams(0,dp(40),1f))
 }
}
