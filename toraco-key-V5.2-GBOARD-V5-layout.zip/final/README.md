# Reverse Calc Keyboard v5.2

QWERTY Android IME with calculator suggestions, emoji-name suggestions, reverse modes, alternate case, spaced double, and compact double (`hello` -> `hheelllloo`).

Layout is based on V5 for the keyboard label/navigation geometry. The bottom row keeps the Gboard-style key order with Backspace in the Gboard position and a dedicated navigation-bar area outside the keyboard.

GitHub Actions builds the debug APK without a PC.
