plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.abhi.reversecalc"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.abhi.reversecalc"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "5.2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
