package com.abhi.reversecalc

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView

class KeyboardService : InputMethodService() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private lateinit var root: LinearLayout
    private lateinit var suggestions: LinearLayout

    private enum class Mode { REVERSE, MONO, DOUBLE, DOUBLE_COMPACT, ALT_CASE, SPACED_DOUBLE }
    private var mode = Mode.REVERSE
    private var symbols = false
    private var shift = false

    // Colours matched to the dark Gboard screenshot supplied by the user.
    private val keyboardBg = Color.rgb(47, 48, 50)
    private val keyBg = Color.rgb(70, 73, 78)
    private val suggestionBg = Color.rgb(61, 64, 68)
    private val keyText = Color.rgb(245, 245, 245)

    private val backspaceHandler = Handler(Looper.getMainLooper())
    private var backspaceDeleting = false
    private var backspaceBurstStarted = false
    private val backspaceRunnable = object : Runnable {
        override fun run() {
            if (!backspaceDeleting) return
            currentInputConnection?.deleteSurroundingText(1, 0)
            update()
            backspaceHandler.postDelayed(this, 55)
        }
    }

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
            setPadding(dp(3), dp(3), dp(3), dp(5))
            setBackgroundColor(keyboardBg)
            clipToPadding = false
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(285)
            )
        }

        suggestions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(suggestions, LinearLayout.LayoutParams(-1, dp(40)))

        rebuild()
        update()
        return root
    }

    private fun rebuild() {
        while (root.childCount > 1) root.removeViewAt(1)

        if (symbols) {
            row("1234567890", 0f)
            row("@#$%&*()-+", 0.45f)
            row(".,!?/:;'\"", 0.9f)
        } else {
            row("qwertyuiop", 0f)
            row("asdfghjkl", 0.45f)
            row("zxcvbnm", 0.9f)
        }

        // Gboard-style bottom row:
        // 123 | Shift | ↔ |       SPACE       | Backspace | Enter
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        bottomButton(bottom, if (symbols) "ABC" else "123", 1.0f) {
            symbols = !symbols
            rebuild()
            update()
        }
        bottomButton(bottom, "⇧", 0.9f) {
            shift = !shift
            rebuild()
            update()
        }
        bottomButton(bottom, "↔", 0.9f) {
            mode = when (mode) {
                Mode.REVERSE -> Mode.MONO
                Mode.MONO -> Mode.DOUBLE
                Mode.DOUBLE -> Mode.DOUBLE_COMPACT
                Mode.DOUBLE_COMPACT -> Mode.ALT_CASE
                Mode.ALT_CASE -> Mode.SPACED_DOUBLE
                Mode.SPACED_DOUBLE -> Mode.REVERSE
            }
            update()
        }
        bottomButton(bottom, "SPACE", 5.0f) {
            commit(" ")
            update()
        }
        bottomButton(bottom, "⌫", 1.0f, backspaceEnabled = true, icon = true) {
            currentInputConnection?.deleteSurroundingText(1, 0)
            update()
        }
        bottomButton(bottom, "↵", 1.0f) {
            currentInputConnection?.sendKeyEvent(
                android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER)
            )
            currentInputConnection?.sendKeyEvent(
                android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_ENTER)
            )
            update()
        }
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(58)))
    }

    private fun row(chars: String, sideWeight: Float) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        if (sideWeight > 0f) row.addView(View(this), LinearLayout.LayoutParams(0, -1, sideWeight))
        chars.forEach { c ->
            val label = if (!symbols && shift) c.uppercaseChar().toString() else c.toString()
            bottomButton(row, label) {
                commit(label)
                update()
            }
        }
        if (sideWeight > 0f) row.addView(View(this), LinearLayout.LayoutParams(0, -1, sideWeight))
        root.addView(row, LinearLayout.LayoutParams(-1, dp(58)))
    }

    private fun makeKeyBackground(color: Int = keyBg): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(9).toFloat()
    }

    private fun bottomButton(
        row: LinearLayout,
        label: String,
        weight: Float = 1f,
        backspaceEnabled: Boolean = false,
        icon: Boolean = false,
        action: () -> Unit
    ) {
        val button = Button(this).apply {
            text = label
            textSize = if (icon) 13f else 13f
            isAllCaps = false
            setTextColor(keyText)
            gravity = Gravity.CENTER
            if (icon) {
                setCompoundDrawablesWithIntrinsicBounds(com.abhi.reversecalc.R.drawable.ic_backspace, 0, 0, 0)
                text = ""
                compoundDrawablePadding = 0
            }
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            includeFontPadding = false
            setPadding(0, 0, 0, 0)
            background = makeKeyBackground()
            stateListAnimator = null

            if (backspaceEnabled) {
                setOnTouchListener { _, event ->
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            backspaceDeleting = false
                            backspaceBurstStarted = false
                            backspaceHandler.postDelayed({
                                backspaceDeleting = true
                                backspaceBurstStarted = true
                                backspaceHandler.post(backspaceRunnable)
                            }, 350)
                            true
                        }
                        MotionEvent.ACTION_UP -> {
                            backspaceHandler.removeCallbacksAndMessages(null)
                            val wasBurst = backspaceBurstStarted
                            backspaceDeleting = false
                            backspaceBurstStarted = false
                            if (!wasBurst) action()
                            true
                        }
                        MotionEvent.ACTION_CANCEL -> {
                            backspaceHandler.removeCallbacksAndMessages(null)
                            backspaceDeleting = false
                            backspaceBurstStarted = false
                            true
                        }
                        else -> true
                    }
                }
            } else {
                setOnClickListener { action() }
            }
        }
        val params = LinearLayout.LayoutParams(0, -1, weight).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        }
        row.addView(button, params)
    }

    private fun commit(s: String) {
        currentInputConnection?.commitText(s, 1)
    }

    private fun text() =
        currentInputConnection?.getTextBeforeCursor(500, 0)?.toString() ?: ""

    private fun token(s: String) = s.substringAfterLast(" ")

    private fun modeLabel() = when (mode) {
        Mode.REVERSE -> "↔"
        Mode.MONO -> "M"
        Mode.DOUBLE -> "DD"
        Mode.DOUBLE_COMPACT -> "DD"
        Mode.ALT_CASE -> "aA"
        Mode.SPACED_DOUBLE -> "H H"
    }

    private fun modeName() = when (mode) {
        Mode.REVERSE -> "Reverse"
        Mode.MONO -> "Mono"
        Mode.DOUBLE -> "Double"
        Mode.DOUBLE_COMPACT -> "Double Compact"
        Mode.ALT_CASE -> "Alt Case"
        Mode.SPACED_DOUBLE -> "Spaced Double"
    }

    private fun transformAll(input: String): String = when (mode) {
        Mode.REVERSE -> input.reversed()
        Mode.MONO -> input.split(" ", ignoreCase = false, limit = -1)
            .joinToString(" ") { word -> word.toCharArray().joinToString(" ") }
        Mode.DOUBLE -> input.split(" ", ignoreCase = false, limit = -1)
            .joinToString(" ") { word -> word.toCharArray().joinToString(" ") { ch -> "$ch$ch" } }
        Mode.DOUBLE_COMPACT -> input.split(" ", ignoreCase = false, limit = -1)
            .joinToString(" ") { word ->
                val doubled = word.toCharArray().joinToString("") { ch -> "$ch$ch" }
                if (word.isEmpty()) "-" else "$word-$doubled"
            }
        Mode.ALT_CASE -> {
            var upper = false
            input.map { ch ->
                if (ch == ' ') {
                    upper = false
                    ch
                } else {
                    val out = if (upper) ch.uppercaseChar() else ch.lowercaseChar()
                    upper = !upper
                    out
                }
            }.joinToString("")
        }
        Mode.SPACED_DOUBLE -> input.split(" ", ignoreCase = false, limit = -1)
            .joinToString(" ") { word -> word.toCharArray().joinToString(" ") { ch -> "$ch $ch" } }
    }

    private fun showModeSelector(anchor: View) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(5), dp(6), dp(5))
            setBackgroundColor(keyboardBg)
        }
        fun addMode(label: String, m: Mode) {
            val b = Button(this).apply {
                text = label
                textSize = 13f
                isAllCaps = false
                setTextColor(keyText)
                minHeight = 0
                minimumHeight = 0
                minWidth = 0
                minimumWidth = 0
                setPadding(dp(10), 0, dp(10), 0)
                background = makeKeyBackground(suggestionBg)
                setOnClickListener {
                    mode = m
                    popup.dismiss()
                    update()
                }
            }
            box.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            })
        }
        addMode("Reverse", Mode.REVERSE)
        addMode("Mono", Mode.MONO)
        addMode("Double", Mode.DOUBLE)
        addMode("HH", Mode.DOUBLE_COMPACT)
        addMode("Alt Case", Mode.ALT_CASE)
        addMode("H H", Mode.SPACED_DOUBLE)
        popup = PopupWindow(box, dp(360), dp(52), true).apply {
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(keyboardBg))
            elevation = dp(8).toFloat()
            isOutsideTouchable = true
        }
        popup.showAsDropDown(anchor, -dp(4), -dp(48))
    }

    private lateinit var popup: PopupWindow

    private fun addModeSwitchButton() {
        val button = Button(this).apply {
            text = "▦"
            textSize = 18f
            isAllCaps = false
            setTextColor(keyText)
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            setPadding(0, 0, 0, 0)
            background = makeKeyBackground(suggestionBg)
            setOnClickListener { showModeSelector(this) }
        }
        suggestions.addView(button, LinearLayout.LayoutParams(dp(42), -1).apply {
            setMargins(dp(2), dp(1), dp(2), dp(1))
        })
    }

    private fun update() {
        if (!::suggestions.isInitialized) return
        suggestions.removeAllViews()
        addModeSwitchButton()

        val all = text()
        val tok = token(all)

        Calculator.calculate(tok)?.let { suggest(it) }
        EmojiData.search(tok).forEach { suggest(it.emoji) }
        if (all.isNotEmpty()) suggest(transformAll(all), replaceAll = true)

        if (suggestions.childCount == 1) {
            suggestions.addView(TextView(this).apply {
                text = "${modeName()} mode • type calculation or emoji name"
                textSize = 13f
                setTextColor(keyText)
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), 0, dp(8), 0)
            })
        }
    }

    private fun suggest(v: String, replaceAll: Boolean = false) {
        val button = Button(this).apply {
            text = v
            textSize = 15f
            isAllCaps = false
            setTextColor(keyText)
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(4), 0, dp(4), 0)
            background = makeKeyBackground(suggestionBg)
            setOnClickListener {
                val all = text()
                val count = if (replaceAll) all.length else token(all).length
                if (count > 0) currentInputConnection?.deleteSurroundingText(count, 0)
                commit(v)
                update()
            }
        }
        suggestions.addView(button, LinearLayout.LayoutParams(0, -1, 1f).apply {
            setMargins(dp(2), dp(1), dp(2), dp(1))
        })
    }
}
