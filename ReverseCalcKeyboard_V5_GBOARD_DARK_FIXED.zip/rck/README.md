# Reverse Calc Keyboard V5 — Gboard Dark Match

Android QWERTY IME with calculator suggestions, emoji-name suggestions, and whole-text transformation modes.

Modes:
- Reverse: `hello world` → `dlrow olleh`
- Mono: `hello` → `h e l l o`
- Double: `hello` → `hh ee ll ll oo`
- Alt Case: `hello` → `hElLo`
- Spaced Double: `hello` → `h h e e l l l l o o`

The keyboard layout is adjusted to match the supplied dark Gboard screenshots. The bottom row uses the Gboard-style order and places **Backspace immediately to the right of Space**, followed by Enter.

The project targets Android API 35 and uses Kotlin/Android Gradle Plugin. GitHub Actions can build the debug APK without a local PC.
