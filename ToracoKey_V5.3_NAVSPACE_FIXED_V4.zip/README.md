# Toraco Key V5.3

QWERTY Android IME with calculator suggestions, emoji-name suggestions, and whole-text transformation modes.

Modes: Reverse, Mono, Double, Alt Case, and H H.

The mode selector is kept inside the suggestion bar; no PopupWindow is used, avoiding IME window-token crashes during mode switching.
