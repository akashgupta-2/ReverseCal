package com.abhi.reversecalc

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class KeyboardService : InputMethodService() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private lateinit var root: LinearLayout
    private lateinit var suggestions: LinearLayout
    private var reverse = false
    private var symbols = false
    private var shift = false
    private var navInset = 0

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(3), dp(3), 0)
            setBackgroundColor(Color.rgb(235, 235, 235))
            clipToPadding = false
        }

        root.setOnApplyWindowInsetsListener { view, insets ->
            val bottom = insets.getInsets(WindowInsets.Type.navigationBars()).bottom
            if (bottom != navInset) {
                navInset = bottom
                view.setPadding(dp(3), dp(3), dp(3), navInset)
                rebuild()
            }
            insets
        }

        suggestions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(suggestions, LinearLayout.LayoutParams(-1, dp(40)))

        rebuild()
        update()
        root.requestApplyInsets()
        return root
    }

    private fun rebuild() {
        while (root.childCount > 1) root.removeViewAt(1)

        if (symbols) {
            row("1234567890")
            row("@#$%&*()-+")
            row(".,!?/:;'\"")
        } else {
            row("qwertyuiop")
            row("asdfghjkl")
            row("zxcvbnm")
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        bottomButton(bottom, if (symbols) "ABC" else "123") {
            symbols = !symbols
            rebuild()
            update()
        }
        bottomButton(bottom, "⇧") {
            shift = !shift
            rebuild()
            update()
        }
        bottomButton(bottom, if (reverse) "REV" else "↔") {
            reverse = !reverse
            update()
        }
        bottomButton(bottom, "SPACE", 2.5f) {
            commit(" ")
            update()
        }
        bottomButton(bottom, "⌫") {
            currentInputConnection.deleteSurroundingText(1, 0)
            update()
        }
        bottomButton(bottom, "↵") {
            currentInputConnection.sendKeyEvent(
                android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, 66)
            )
            currentInputConnection.sendKeyEvent(
                android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, 66)
            )
            update()
        }
        root.addView(bottom, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun row(chars: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        chars.forEach { c ->
            val label = if (!symbols && shift) c.uppercaseChar().toString() else c.toString()
            bottomButton(row, label) {
                commit(label)
                update()
            }
        }
        root.addView(row, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun bottomButton(
        row: LinearLayout,
        label: String,
        weight: Float = 1f,
        action: () -> Unit
    ) {
        val button = Button(this).apply {
            text = label
            textSize = 14f
            isAllCaps = false
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(2), 0, dp(2), 0)
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(8).toFloat()
            }
            setOnClickListener { action() }
        }
        val params = LinearLayout.LayoutParams(0, -1, weight).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        }
        row.addView(button, params)
    }

    private fun commit(s: String) {
        currentInputConnection.commitText(s, 1)
    }

    private fun text() =
        currentInputConnection.getTextBeforeCursor(500, 0)?.toString() ?: ""

    private fun token(s: String) = s.substringAfterLast(" ")

    private fun update() {
        if (!::suggestions.isInitialized) return
        suggestions.removeAllViews()
        val all = text()
        val tok = token(all)

        Calculator.calculate(tok)?.let { suggest(it) }
        EmojiData.search(tok).forEach { suggest(it.emoji) }
        if (reverse && all.isNotEmpty()) suggest(all.reversed())

        if (suggestions.childCount == 0) {
            suggestions.addView(TextView(this).apply {
                text = if (reverse) "↔ Reverse: whole text" else "Type calculation or emoji name"
                textSize = 13f
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(10), 0)
            })
        }
    }

    private fun suggest(v: String) {
        val button = Button(this).apply {
            text = v
            textSize = 15f
            isAllCaps = false
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(4), 0, dp(4), 0)
            setOnClickListener {
                val all = text()
                val tok = token(all)
                if (tok.isNotEmpty()) currentInputConnection.deleteSurroundingText(tok.length, 0)
                commit(v)
                update()
            }
        }
        suggestions.addView(button, LinearLayout.LayoutParams(0, -1, 1f).apply {
            setMargins(dp(2), dp(1), dp(2), dp(1))
        })
    }
}
