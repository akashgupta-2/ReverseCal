# toraco-key V5

Android QWERTY keyboard with calculator suggestions, emoji-name suggestions, and text transformation modes.

The project is laid out at the repository root so GitHub Actions can build it directly.

Modes:
- Reverse
- Mono
- Double
- Alt Case
- Spaced Double

The keyboard uses the supplied dark Gboard-style appearance and places Backspace immediately to the right of Space, followed by Enter.
