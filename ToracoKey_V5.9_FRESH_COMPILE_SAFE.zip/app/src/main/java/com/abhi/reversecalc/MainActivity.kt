package com.abhi.reversecalc
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
class MainActivity: Activity() {
 override fun onCreate(b: Bundle?) {
  super.onCreate(b)
  val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(30,35,30,20)}
  val t=TextView(this).apply{text="Toraco Key\n\nQWERTY • Calculator • Whole-text Reverse Mode\n\nReverse: hello world → dlrow olleh";textSize=18f}
  val a=Button(this).apply{text="Open Keyboard Settings";setOnClickListener{startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))}}
  val p=Button(this).apply{text="Choose Keyboard";setOnClickListener{(getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()}}
  l.addView(t);l.addView(a);l.addView(p);setContentView(l)
 }
}
