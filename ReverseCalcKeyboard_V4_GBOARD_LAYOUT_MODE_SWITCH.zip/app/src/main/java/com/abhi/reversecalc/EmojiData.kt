package com.abhi.reversecalc
data class EmojiItem(val name:String,val emoji:String)
object EmojiData {
 val items=listOf(
  EmojiItem("grinning","😀"),EmojiItem("smile","😄"),EmojiItem("grin","😁"),EmojiItem("laugh","😂"),
  EmojiItem("rofl","🤣"),EmojiItem("wink","😉"),EmojiItem("blush","😊"),EmojiItem("love","😍"),
  EmojiItem("kiss","😘"),EmojiItem("thinking","🤔"),EmojiItem("cool","😎"),EmojiItem("cry","😢"),
  EmojiItem("sob","😭"),EmojiItem("angry","😠"),EmojiItem("confused","😕"),EmojiItem("sleep","😴"),
  EmojiItem("heart","❤️"),EmojiItem("broken heart","💔"),EmojiItem("fire","🔥"),EmojiItem("star","⭐"),
  EmojiItem("sparkles","✨"),EmojiItem("thumbs up","👍"),EmojiItem("thumbs down","👎"),EmojiItem("clap","👏"),
  EmojiItem("ok","👌"),EmojiItem("pray","🙏"),EmojiItem("muscle","💪"),EmojiItem("party","🥳"),
  EmojiItem("rocket","🚀"),EmojiItem("airplane","✈️"),EmojiItem("car","🚗"),EmojiItem("train","🚆"),
  EmojiItem("dog","🐶"),EmojiItem("cat","🐱"),EmojiItem("pizza","🍕"),EmojiItem("burger","🍔"),
  EmojiItem("coffee","☕"),EmojiItem("check","✅"),EmojiItem("cross","❌"),EmojiItem("warning","⚠️"),
  EmojiItem("party popper","🎉"))
 fun search(q:String)=items.filter{it.name.contains(q.trim(),true)}.take(5)
}
