package com.abhi.reversecalc
import kotlin.math.pow
object Calculator {
 fun calculate(input:String):String? {
  val s=input.replace(" ","")
  if(s.isEmpty() || !s.matches(Regex("[0-9+\\-*/%.()^]+"))) return null
  return try {
   val v=P(s).parse()
   if(!v.isFinite()) null else if(v==v.toLong().toDouble()) v.toLong().toString()
   else "%.10f".format(v).trimEnd('0').trimEnd('.')
  } catch(_:Exception){null}
 }
 private class P(private val s:String){var p=0
  fun parse():Double{val v=e();if(p!=s.length)error("extra");return v}
  fun e():Double{var v=t();while(p<s.length&&(s[p]=='+'||s[p]=='-')){val o=s[p++];val r=t();v=if(o=='+')v+r else v-r};return v}
  fun t():Double{var v=pow();while(p<s.length&&(s[p]=='*'||s[p]=='/')){val o=s[p++];val r=pow();if(o=='/'&&r==0.0)error("zero");v=if(o=='*')v*r else v/r};return v}
  fun pow():Double{var v=u();if(p<s.length&&s[p]=='^'){p++;v=v.pow(pow())};return v}
  fun u():Double{if(p<s.length&&s[p]=='+'){p++;return u()};if(p<s.length&&s[p]=='-'){p++;return -u()};return n()}
  fun n():Double{if(p<s.length&&s[p]=='('){p++;val v=e();if(p>=s.length||s[p++]!=')')error(")");return v};val st=p;while(p<s.length&&(s[p].isDigit()||s[p]=='.'))p++;if(st==p)error("num");return s.substring(st,p).toDouble()}
 }
}
