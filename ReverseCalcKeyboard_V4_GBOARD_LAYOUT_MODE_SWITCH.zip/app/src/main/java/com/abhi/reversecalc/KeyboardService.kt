package com.abhi.reversecalc

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.PopupWindow

class KeyboardService : InputMethodService() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private lateinit var root: LinearLayout
    private lateinit var suggestions: LinearLayout
    private enum class Mode { REVERSE, MONO, DOUBLE }
    private var mode = Mode.REVERSE
    private var symbols = false
    private var shift = false
    private var navInset = 0
    private val keyboardHeightDp = 350
    // Extra bottom inset keeps the key layout shorter while preserving the overall IME height.
    private val extraNavigationSpaceDp = 24
    private val backspaceHandler = Handler(Looper.getMainLooper())
    private var backspaceDeleting = false
    private var backspaceBurstStarted = false
    private val backspaceRunnable = object : Runnable {
        override fun run() {
            if (!backspaceDeleting) return
            currentInputConnection?.deleteSurroundingText(1, 0)
            update()
            backspaceHandler.postDelayed(this, 55)
        }
    }

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(3), dp(3), dp(extraNavigationSpaceDp))
            setBackgroundColor(Color.rgb(235, 235, 235))
            clipToPadding = false
            minimumHeight = dp(keyboardHeightDp)
        }

        root.setOnApplyWindowInsetsListener { view, insets ->
            val bottom = insets.getInsets(WindowInsets.Type.navigationBars()).bottom
            if (bottom != navInset) {
                navInset = bottom
                view.setPadding(dp(3), dp(3), dp(3), navInset + dp(extraNavigationSpaceDp))
                rebuild()
            }
            insets
        }

        suggestions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(suggestions, LinearLayout.LayoutParams(-1, dp(40)))

        rebuild()
        update()
        root.requestApplyInsets()
        return root
    }

    private fun rebuild() {
        while (root.childCount > 1) root.removeViewAt(1)

        if (symbols) {
            row("1234567890", 0f)
            row("@#$%&*()-+", 0.45f)
            row(".,!?/:;'\"", 0.9f)
        } else {
            row("qwertyuiop", 0f)
            row("asdfghjkl", 0.45f)
            row("zxcvbnm", 0.9f)
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        bottomButton(bottom, if (symbols) "ABC" else "123", 1.0f) {
            symbols = !symbols
            rebuild()
            update()
        }
        bottomButton(bottom, "⇧", 0.9f) {
            shift = !shift
            rebuild()
            update()
        }
        bottomButton(bottom, modeLabel(), 0.9f) {
            mode = when (mode) {
                Mode.REVERSE -> Mode.MONO
                Mode.MONO -> Mode.DOUBLE
                Mode.DOUBLE -> Mode.REVERSE
            }
            update()
            rebuild()
        }
        bottomButton(bottom, "SPACE", 2.6f) {
            commit(" ")
            update()
        }
        bottomButton(bottom, "⌫", 1.0f, backspaceEnabled = true) {
            currentInputConnection?.deleteSurroundingText(1, 0)
            update()
        }
        bottomButton(bottom, "↵", 1.0f) {
            currentInputConnection.sendKeyEvent(
                android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, 66)
            )
            currentInputConnection.sendKeyEvent(
                android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, 66)
            )
            update()
        }
        root.addView(bottom, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun row(chars: String, sideWeight: Float) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        if (sideWeight > 0f) row.addView(View(this), LinearLayout.LayoutParams(0, -1, sideWeight))
        chars.forEach { c ->
            val label = if (!symbols && shift) c.uppercaseChar().toString() else c.toString()
            bottomButton(row, label) {
                commit(label)
                update()
            }
        }
        if (sideWeight > 0f) row.addView(View(this), LinearLayout.LayoutParams(0, -1, sideWeight))
        root.addView(row, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun bottomButton(
        row: LinearLayout,
        label: String,
        weight: Float = 1f,
        backspaceEnabled: Boolean = false,
        action: () -> Unit
    ) {
        val button = Button(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(2), 0, dp(2), 0)
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(8).toFloat()
            }
            if (backspaceEnabled) {
                setOnTouchListener { _, event ->
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            backspaceDeleting = false
                            backspaceBurstStarted = false
                            backspaceHandler.postDelayed({
                                backspaceDeleting = true
                                backspaceBurstStarted = true
                                backspaceHandler.post(backspaceRunnable)
                            }, 350)
                            true
                        }
                        MotionEvent.ACTION_UP -> {
                            backspaceHandler.removeCallbacksAndMessages(null)
                            val wasBurst = backspaceBurstStarted
                            backspaceDeleting = false
                            backspaceBurstStarted = false
                            if (!wasBurst) action()
                            true
                        }
                        MotionEvent.ACTION_CANCEL -> {
                            backspaceHandler.removeCallbacksAndMessages(null)
                            backspaceDeleting = false
                            backspaceBurstStarted = false
                            true
                        }
                        else -> true
                    }
                }
            } else {
                setOnClickListener { action() }
            }
        }
        val params = LinearLayout.LayoutParams(0, -1, weight).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        }
        row.addView(button, params)
    }

    private fun commit(s: String) {
        currentInputConnection.commitText(s, 1)
    }

    private fun text() =
        currentInputConnection.getTextBeforeCursor(500, 0)?.toString() ?: ""

    private fun token(s: String) = s.substringAfterLast(" ")

    private fun modeLabel() = when (mode) {
        Mode.REVERSE -> "↔"
        Mode.MONO -> "M"
        Mode.DOUBLE -> "DD"
    }

    private fun modeName() = when (mode) {
        Mode.REVERSE -> "Reverse"
        Mode.MONO -> "Mono"
        Mode.DOUBLE -> "Double"
    }

    private fun transformAll(input: String): String {
        val compact = input.replace(" ", "")
        return when (mode) {
            Mode.REVERSE -> compact.reversed()
            Mode.MONO -> compact.map { it }.joinToString(" ")
            Mode.DOUBLE -> compact.map { "$it$it" }.joinToString(" ")
        }
    }

    private fun showModeSelector(anchor: View) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(5), dp(6), dp(5))
            setBackgroundColor(Color.WHITE)
        }
        fun addMode(label: String, m: Mode) {
            val b = Button(this).apply {
                text = label
                textSize = 13f
                isAllCaps = false
                minHeight = 0
                minimumHeight = 0
                minWidth = 0
                minimumWidth = 0
                setPadding(dp(10), 0, dp(10), 0)
                setOnClickListener {
                    mode = m
                    popup.dismiss()
                    update()
                    rebuild()
                }
            }
            box.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            })
        }
        addMode("Reverse", Mode.REVERSE)
        addMode("Mono", Mode.MONO)
        addMode("Double", Mode.DOUBLE)
        popup = PopupWindow(box, dp(285), dp(52), true).apply {
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.WHITE))
            elevation = dp(8).toFloat()
            isOutsideTouchable = true
            setOnDismissListener { }
        }
        popup.showAsDropDown(anchor, -dp(4), -dp(48))
    }

    private lateinit var popup: PopupWindow

    private fun addModeSwitchButton() {
        val button = Button(this).apply {
            text = "▦"
            textSize = 18f
            isAllCaps = false
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            setPadding(0, 0, 0, 0)
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(8).toFloat()
            }
            setOnClickListener { showModeSelector(this) }
        }
        suggestions.addView(button, LinearLayout.LayoutParams(dp(42), -1).apply {
            setMargins(dp(2), dp(1), dp(2), dp(1))
        })
    }

    private fun update() {
        if (!::suggestions.isInitialized) return
        suggestions.removeAllViews()
        addModeSwitchButton()

        val all = text()
        val tok = token(all)

        Calculator.calculate(tok)?.let { suggest(it) }
        EmojiData.search(tok).forEach { suggest(it.emoji) }
        // Transformation modes operate on the entire text, so a suggestion never
        // replaces only the last word with a transformed full sentence.
        if (all.isNotEmpty()) suggest(transformAll(all), replaceAll = true)

        if (suggestions.childCount == 1) {
            suggestions.addView(TextView(this).apply {
                text = "${modeName()} mode • type calculation or emoji name"
                textSize = 13f
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), 0, dp(8), 0)
            })
        }
    }

    private fun suggest(v: String, replaceAll: Boolean = false) {
        val button = Button(this).apply {
            text = v
            textSize = 15f
            isAllCaps = false
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(4), 0, dp(4), 0)
            setOnClickListener {
                val all = text()
                val count = if (replaceAll) all.length else token(all).length
                if (count > 0) currentInputConnection.deleteSurroundingText(count, 0)
                commit(v)
                update()
            }
        }
        suggestions.addView(button, LinearLayout.LayoutParams(0, -1, 1f).apply {
            setMargins(dp(2), dp(1), dp(2), dp(1))
        })
    }
}
