package com.abhi.reversecalc

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.PopupWindow
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager

class KeyboardService : InputMethodService() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private lateinit var root: LinearLayout
    private lateinit var suggestions: LinearLayout
    private enum class Mode { REVERSE, MONO, DOUBLE, ALT_CASE, SPACED_DOUBLE }
    private var mode = Mode.REVERSE
    private var symbols = false
    private var shift = false
    private val keyboardHeightDp = 300
    // Extra bottom inset so the Android navigation/gesture bar never crowds the keyboard.
    private val navigationSpaceDp = 36
    private val backspaceHandler = Handler(Looper.getMainLooper())
    private var backspaceDeleting = false
    private var backspaceBurstStarted = false
    private val backspaceRunnable = object : Runnable {
        override fun run() {
            if (!backspaceDeleting) return
            currentInputConnection?.deleteSurroundingText(1, 0)
            update()
            backspaceHandler.postDelayed(this, 55)
        }
    }

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(3), dp(3), dp(navigationSpaceDp))
            setBackgroundColor(Color.rgb(235, 235, 235))
            clipToPadding = false
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(keyboardHeightDp)
            )
        }

        suggestions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(suggestions, LinearLayout.LayoutParams(-1, dp(40)))

        rebuild()
        update()
        return root
    }

    private fun rebuild() {
        while (root.childCount > 1) root.removeViewAt(1)

        if (symbols) {
            row("1234567890", 0f)
            row("@#$%&*()-+", 0.45f)
            row(".,!?/:;'\"", 0.9f)
        } else {
            row("qwertyuiop", 0f)
            row("asdfghjkl", 0.45f)
            row("zxcvbnm", 0.9f, includeBackspace = true)
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        bottomButton(bottom, if (symbols) "ABC" else "123", 1.0f) {
            symbols = !symbols
            rebuild()
            update()
        }

        bottomButton(bottom, "⇧", 0.9f) {
            shift = !shift
            rebuild()
            update()
        }

        bottomButton(bottom, modeLabel(), 0.9f) {
            mode = when (mode) {
                Mode.REVERSE -> Mode.MONO
                Mode.MONO -> Mode.DOUBLE
                Mode.DOUBLE -> Mode.ALT_CASE
                Mode.ALT_CASE -> Mode.SPACED_DOUBLE
                Mode.SPACED_DOUBLE -> Mode.REVERSE
            }
            safeUpdateAndRebuild()
        }

        bottomButton(bottom, "SPACE", 2.6f) {
            commit(" ")
            update()
        }

        // Gboard-style globe key.
        bottomButton(bottom, "🌐", 0.9f) {
            (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
                ?.showInputMethodPicker()
        }

        bottomButton(bottom, "↵", 0.9f) {
            currentInputConnection?.sendKeyEvent(
                android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, 66)
            )
            currentInputConnection?.sendKeyEvent(
                android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, 66)
            )
            update()
        }

        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(52)))
    }

    private fun row(
        chars: String,
        sideWeight: Float,
        includeBackspace: Boolean = false
    ) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        if (sideWeight > 0f) {
            row.addView(
                View(this),
                LinearLayout.LayoutParams(0, -1, sideWeight)
            )
        }

        chars.forEach { c ->
            val label =
                if (!symbols && shift) c.uppercaseChar().toString()
                else c.toString()

            bottomButton(row, label) {
                commit(label)
                update()
            }
        }

        if (includeBackspace) {
            bottomButton(
                row,
                "⌫",
                1.0f,
                backspaceEnabled = true
            ) {
                currentInputConnection?.deleteSurroundingText(1, 0)
                update()
            }
        }

        if (sideWeight > 0f) {
            row.addView(
                View(this),
                LinearLayout.LayoutParams(0, -1, sideWeight)
            )
        }

        root.addView(
            row,
            LinearLayout.LayoutParams(-1, dp(54))
        )
    }

    private fun bottomButton(
        row: LinearLayout,
        label: String,
        weight: Float = 1f,
        backspaceEnabled: Boolean = false,
        action: () -> Unit
    ) {
        val button = Button(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(2), 0, dp(2), 0)
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(8).toFloat()
            }
            if (backspaceEnabled) {
                setOnTouchListener { _, event ->
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            backspaceDeleting = false
                            backspaceBurstStarted = false
                            backspaceHandler.postDelayed({
                                backspaceDeleting = true
                                backspaceBurstStarted = true
                                backspaceHandler.post(backspaceRunnable)
                            }, 350)
                            true
                        }
                        MotionEvent.ACTION_UP -> {
                            backspaceHandler.removeCallbacksAndMessages(null)
                            val wasBurst = backspaceBurstStarted
                            backspaceDeleting = false
                            backspaceBurstStarted = false
                            if (!wasBurst) action()
                            true
                        }
                        MotionEvent.ACTION_CANCEL -> {
                            backspaceHandler.removeCallbacksAndMessages(null)
                            backspaceDeleting = false
                            backspaceBurstStarted = false
                            true
                        }
                        else -> true
                    }
                }
            } else {
                setOnClickListener { action() }
            }
        }
        val params = LinearLayout.LayoutParams(0, -1, weight).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        }
        row.addView(button, params)
    }

    private fun commit(s: String) {
        currentInputConnection?.commitText(s, 1)
    }

    private fun text(): String =
        currentInputConnection?.getTextBeforeCursor(500, 0)?.toString() ?: ""

    private fun safeUpdateAndRebuild() {
        // Mode switching can briefly invalidate the IME connection while the
        // popup is being dismissed. Rebuild only after the current UI event.
        backspaceHandler.removeCallbacksAndMessages(null)
        backspaceDeleting = false
        backspaceBurstStarted = false
        root.post {
            if (!::root.isInitialized || root.parent == null) return@post
            try {
                rebuild()
                update()
            } catch (_: Exception) {
                // Do not allow a transient IME/UI exception to terminate the keyboard.
            }
        }
    }

    private fun token(s: String) = s.substringAfterLast(" ")

    private fun modeLabel() = when (mode) {
        Mode.REVERSE -> "↔"
        Mode.MONO -> "M"
        Mode.DOUBLE -> "DD"
        Mode.ALT_CASE -> "aA"
        Mode.SPACED_DOUBLE -> "H H"
    }

    private fun modeName() = when (mode) {
        Mode.REVERSE -> "Reverse"
        Mode.MONO -> "Mono"
        Mode.DOUBLE -> "Double"
        Mode.ALT_CASE -> "Alt Case"
        Mode.SPACED_DOUBLE -> "Spaced Double"
    }

    private fun transformAll(input: String): String {
        return when (mode) {
            Mode.REVERSE -> input.reversed()
            Mode.MONO -> input.split(" ", ignoreCase = false, limit = -1)
                .joinToString(" ") { word -> word.toCharArray().joinToString(" ") }
            Mode.DOUBLE -> input.split(" ", ignoreCase = false, limit = -1)
                .joinToString(" ") { word -> word.toCharArray().joinToString(" ") { ch -> "$ch$ch" } }
            Mode.ALT_CASE -> {
                var upper = false
                input.map { ch ->
                    if (ch == ' ') {
                        upper = false
                        ch
                    } else {
                        val out = if (upper) ch.uppercaseChar() else ch.lowercaseChar()
                        upper = !upper
                        out
                    }
                }.joinToString("")
            }
            Mode.SPACED_DOUBLE -> input.split(" ", ignoreCase = false, limit = -1)
                .joinToString(" ") { word -> word.toCharArray().joinToString(" ") { ch -> "$ch $ch" } }
        }
    }

    private fun showModeSelector(anchor: View) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(5), dp(6), dp(5))
            setBackgroundColor(Color.WHITE)
        }
        fun addMode(label: String, m: Mode) {
            val b = Button(this).apply {
                text = label
                textSize = 13f
                isAllCaps = false
                minHeight = 0
                minimumHeight = 0
                minWidth = 0
                minimumWidth = 0
                setPadding(dp(10), 0, dp(10), 0)
                setOnClickListener {
                    mode = m
                    popup.dismiss()
                    safeUpdateAndRebuild()
                }
            }
            box.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                setMargins(dp(2), 0, dp(2), 0)
            })
        }
        addMode("Reverse", Mode.REVERSE)
        addMode("Mono", Mode.MONO)
        addMode("Double", Mode.DOUBLE)
        addMode("Alt Case", Mode.ALT_CASE)
        addMode("H H", Mode.SPACED_DOUBLE)
        popup = PopupWindow(box, dp(360), dp(52), true).apply {
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.WHITE))
            elevation = dp(8).toFloat()
            isOutsideTouchable = true
            setOnDismissListener { }
        }
        if (!popup.isShowing) {
            popup.showAsDropDown(anchor, -dp(4), -dp(48))
        }
    }

    private lateinit var popup: PopupWindow

    private fun addModeSwitchButton() {
        val button = Button(this).apply {
            text = "▦"
            textSize = 18f
            isAllCaps = false
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            setPadding(0, 0, 0, 0)
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(8).toFloat()
            }
            setOnClickListener { showModeSelector(this) }
        }
        suggestions.addView(button, LinearLayout.LayoutParams(dp(42), -1).apply {
            setMargins(dp(2), dp(1), dp(2), dp(1))
        })
    }

    private fun update() {
        if (!::suggestions.isInitialized) return
        suggestions.removeAllViews()
        addModeSwitchButton()

        val all = text()
        val tok = token(all)

        Calculator.calculate(tok)?.let { suggest(it) }
        EmojiData.search(tok).forEach { suggest(it.emoji) }
        // Transformation modes operate on the entire text, so a suggestion never
        // replaces only the last word with a transformed full sentence.
        if (all.isNotEmpty()) suggest(transformAll(all), replaceAll = true)

        if (suggestions.childCount == 1) {
            suggestions.addView(TextView(this).apply {
                text = "${modeName()} mode • type calculation or emoji name"
                textSize = 13f
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), 0, dp(8), 0)
            })
        }
    }

    private fun suggest(v: String, replaceAll: Boolean = false) {
        val button = Button(this).apply {
            text = v
            textSize = 15f
            isAllCaps = false
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(4), 0, dp(4), 0)
            setOnClickListener {
                val all = text()
                val count = if (replaceAll) all.length else token(all).length
                val ic = currentInputConnection ?: return@setOnClickListener
                if (count > 0) ic.deleteSurroundingText(count, 0)
                ic.commitText(v, 1)
                update()
            }
        }
        suggestions.addView(button, LinearLayout.LayoutParams(0, -1, 1f).apply {
            setMargins(dp(2), dp(1), dp(2), dp(1))
        })
    }
}
