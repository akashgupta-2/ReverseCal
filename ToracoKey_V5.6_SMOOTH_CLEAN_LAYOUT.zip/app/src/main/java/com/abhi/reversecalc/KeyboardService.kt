package com.abhi.reversecalc

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class KeyboardService : InputMethodService() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private lateinit var root: LinearLayout
    private lateinit var suggestions: LinearLayout

    private enum class Mode { REVERSE, MONO, DOUBLE, ALT_CASE, SPACED_DOUBLE, HELLO_STYLE }
    private var mode = Mode.REVERSE
    private var symbols = false
    private var shift = false

    // Same dark Gboard-style palette used by the earlier V5 layout.
    private val keyboardBg = Color.rgb(47, 48, 50)
    private val keyBg = Color.rgb(70, 73, 78)
    private val suggestionBg = Color.rgb(61, 64, 68)
    private val keyText = Color.rgb(245, 245, 245)

    // A little extra room at the bottom for Android's gesture/navigation area.
    private val navigationSpaceDp = 52

    private val backspaceHandler = Handler(Looper.getMainLooper())
    private var backspaceDeleting = false
    private var backspaceBurstStarted = false
    private val backspaceRunnable = object : Runnable {
        override fun run() {
            if (!backspaceDeleting) return
            safeDelete(1)
            backspaceHandler.postDelayed(this, 55)
        }
    }

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(dp(3), dp(3), dp(3), dp(3))
            setBackgroundColor(keyboardBg)
            clipToPadding = true
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        suggestions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(keyboardBg)
        }
        root.addView(suggestions, LinearLayout.LayoutParams(-1, dp(40)))

        rebuildKeyboard()
        renderEmojiStrip()
        return root
    }

    private fun rebuildKeyboard() {
        if (!::root.isInitialized) return
        while (root.childCount > 1) root.removeViewAt(1)

        if (symbols) {
            row("1234567890", 0f)
            row("@#$%&*()-+", 0.45f)
            row(".,!?/:;'\"=", 0.45f, includeBackspace = true)
        } else {
            row("qwertyuiop", 0f)
            row("asdfghjkl", 0.45f)
            row("zxcvbnm", 0.45f, includeBackspace = true, includeCaps = true)
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        // Keep the existing Gboard-like bottom layout. Backspace stays on
        // the right side of the letter row and is NOT moved here.
        key(bottom, if (symbols) "ABC" else "?123", 1.0f) {
            symbols = !symbols
            rebuildKeyboard()
            updateSuggestions()
        }
        key(bottom, if (symbols) "," else ",", 0.9f) {
            safeCommit(",")
            updateSuggestions()
        }
        key(bottom, "SPACE", 4.8f) {
            safeCommit(" ")
            updateSuggestions()
        }
        key(bottom, "🌐", 0.9f) {
            try {
                (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
                    ?.showInputMethodPicker()
            } catch (_: Exception) { }
        }
        key(bottom, "↵", 0.9f) {
            safeEnter()
            updateSuggestions()
        }

        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(58)))

        // Dedicated blank area below the keyboard, matching the larger
        // Gboard-style navigation/gesture area. This is real layout space,
        // not bottom padding, so it cannot be clipped by the fixed height.
        root.addView(View(this), LinearLayout.LayoutParams(-1, dp(navigationSpaceDp)))
    }

    private fun row(chars: String, sideWeight: Float, includeBackspace: Boolean = false, includeCaps: Boolean = false) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        if (sideWeight > 0f) {
            r.addView(View(this), LinearLayout.LayoutParams(0, -1, sideWeight))
        }

        if (includeCaps) {
            key(r, "⇧", 1.35f) {
                shift = !shift
                rebuildKeyboard()
                updateSuggestions()
            }
        }

        chars.forEach { c ->
            val label = if (!symbols && shift) c.uppercaseChar().toString() else c.toString()
            key(r, label) {
                if (!symbols && label.length == 1 && label[0].isLetter()) {
                    typeWithMode(label[0])
                } else {
                    safeCommit(label)
                }
                updateSuggestions()
            }
        }

        if (includeBackspace) {
            key(r, "⌫", 1.35f, backspaceEnabled = true) {
                safeDelete(1)
                updateSuggestions()
            }
        }

        if (sideWeight > 0f) {
            r.addView(View(this), LinearLayout.LayoutParams(0, -1, sideWeight))
        }

        root.addView(r, LinearLayout.LayoutParams(-1, dp(58)))
    }

    private fun key(
        row: LinearLayout,
        label: String,
        weight: Float = 1f,
        backspaceEnabled: Boolean = false,
        action: () -> Unit
    ) {
        val button = Button(this).apply {
            text = label
            textSize = if (label == "SPACE") 13f else 13f
            isAllCaps = false
            setTextColor(keyText)
            gravity = Gravity.CENTER
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            includeFontPadding = false
            setPadding(0, 0, 0, 0)
            background = makeKeyBackground(keyBg)
            stateListAnimator = null
            isFocusable = false
            isSoundEffectsEnabled = false

            if (backspaceEnabled) {
                setOnTouchListener { _, event ->
                    when (event.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            backspaceDeleting = false
                            backspaceBurstStarted = false
                            backspaceHandler.postDelayed({
                                if (!isAttachedToWindow) return@postDelayed
                                backspaceDeleting = true
                                backspaceBurstStarted = true
                                backspaceHandler.post(backspaceRunnable)
                            }, 350)
                            true
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            backspaceHandler.removeCallbacksAndMessages(null)
                            val burst = backspaceBurstStarted
                            backspaceDeleting = false
                            backspaceBurstStarted = false
                            if (event.actionMasked == MotionEvent.ACTION_UP && !burst) action()
                            true
                        }
                        else -> true
                    }
                }
            } else {
                setOnClickListener {
                    try { action() } catch (_: Exception) { }
                }
            }
        }

        row.addView(button, LinearLayout.LayoutParams(0, -1, weight).apply {
            setMargins(dp(2), dp(2), dp(2), dp(2))
        })
    }

    private fun typeWithMode(ch: Char) {
        try {
            when (mode) {
                Mode.REVERSE -> safeCommit(ch.toString())
                Mode.MONO -> safeCommit("$ch ")
                Mode.DOUBLE -> safeCommit("$ch$ch ")
                Mode.ALT_CASE -> {
                    val before = editorText()
                    val letters = before.count { it.isLetter() }
                    val out = if (letters % 2 == 0) ch.lowercaseChar() else ch.uppercaseChar()
                    safeCommit(out.toString())
                }
                Mode.SPACED_DOUBLE -> safeCommit("$ch $ch ")
                Mode.HELLO_STYLE -> safeCommit("$ch$ch")
            }
        } catch (_: Exception) {
            safeCommit(ch.toString())
        }
    }

    private fun makeKeyBackground(color: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(9).toFloat()
    }

    private fun safeCommit(value: String) {
        try { currentInputConnection?.commitText(value, 1) } catch (_: Exception) { }
    }

    private fun safeDelete(count: Int) {
        try { currentInputConnection?.deleteSurroundingText(count, 0) } catch (_: Exception) { }
    }

    private fun safeEnter() {
        try {
            currentInputConnection?.sendKeyEvent(
                android.view.KeyEvent(
                    android.view.KeyEvent.ACTION_DOWN,
                    android.view.KeyEvent.KEYCODE_ENTER
                )
            )
            currentInputConnection?.sendKeyEvent(
                android.view.KeyEvent(
                    android.view.KeyEvent.ACTION_UP,
                    android.view.KeyEvent.KEYCODE_ENTER
                )
            )
        } catch (_: Exception) { }
    }

    private fun editorText(): String {
        return try {
            currentInputConnection?.getTextBeforeCursor(500, 0)?.toString() ?: ""
        } catch (_: Exception) {
            ""
        }
    }

    private fun token(s: String): String = s.substringAfterLast(" ")

    private fun modeLabel(m: Mode): String = when (m) {
        Mode.REVERSE -> "↔ Reverse"
        Mode.MONO -> "M Mono"
        Mode.DOUBLE -> "DD Double"
        Mode.ALT_CASE -> "aA Alt Case"
        Mode.SPACED_DOUBLE -> "H H"
        Mode.HELLO_STYLE -> "hello-hheelllloo"
    }

    private fun modeName(): String = when (mode) {
        Mode.REVERSE -> "Reverse"
        Mode.MONO -> "Mono"
        Mode.DOUBLE -> "Double"
        Mode.ALT_CASE -> "Alt Case"
        Mode.SPACED_DOUBLE -> "H H"
        Mode.HELLO_STYLE -> "hello-hheelllloo"
    }

    private fun transformAll(input: String): String = when (mode) {
        Mode.REVERSE -> input.reversed()

        Mode.MONO -> input
            .split(" ", ignoreCase = false, limit = -1)
            .joinToString(" ") { word -> word.toCharArray().joinToString(" ") }

        Mode.DOUBLE -> input
            .split(" ", ignoreCase = false, limit = -1)
            .joinToString(" ") { word ->
                word.toCharArray().joinToString(" ") { ch -> "$ch$ch" }
            }

        Mode.ALT_CASE -> {
            var upper = false
            buildString(input.length) {
                input.forEach { ch ->
                    if (ch == ' ') {
                        append(ch)
                        upper = false
                    } else {
                        append(if (upper) ch.uppercaseChar() else ch.lowercaseChar())
                        upper = !upper
                    }
                }
            }
        }

        Mode.SPACED_DOUBLE -> input
            .split(" ", ignoreCase = false, limit = -1)
            .joinToString(" ") { word ->
                word.toCharArray().joinToString(" ") { ch -> "$ch $ch" }
            }

        Mode.HELLO_STYLE -> input
            .map { ch -> if (ch.isLetter()) "$ch$ch" else ch.toString() }
            .joinToString("")
    }

    /**
     * The mode selector is rendered INSIDE the suggestion bar.
     * No PopupWindow is used. PopupWindow was the risky part of the previous
     * implementation because an IME can lose its window token during an
     * editor/mode transition.
     */
    private fun showModeSelector() {
        if (!::suggestions.isInitialized) return

        try {
            suggestions.removeAllViews()

            addModeButton("Reverse", Mode.REVERSE)
            addModeButton("Mono", Mode.MONO)
            addModeButton("Double", Mode.DOUBLE)
            addModeButton("Alt Case", Mode.ALT_CASE)
            addModeButton("H H", Mode.SPACED_DOUBLE)
            addModeButton("hello-hheelllloo", Mode.HELLO_STYLE)
        } catch (_: Exception) {
            updateSuggestions()
        }
    }

    private fun addModeButton(label: String, selected: Mode) {
        val b = Button(this).apply {
            text = if (mode == selected) "✓ $label" else label
            textSize = 13f
            isAllCaps = false
            setTextColor(keyText)
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            includeFontPadding = false
            setPadding(dp(5), 0, dp(5), 0)
            background = makeKeyBackground(if (mode == selected) keyBg else suggestionBg)
            stateListAnimator = null
            setOnClickListener {
                // Only change a local enum and refresh the suggestion row.
                // Do NOT rebuild the keyboard or touch the InputConnection.
                mode = selected
                updateSuggestions()
            }
        }
        suggestions.addView(b, LinearLayout.LayoutParams(0, -1, 1f).apply {
            setMargins(dp(2), dp(1), dp(2), dp(1))
        })
    }

    private fun addModeSwitchButton() {
        val button = Button(this).apply {
            text = "▦"
            textSize = 18f
            isAllCaps = false
            setTextColor(keyText)
            gravity = Gravity.CENTER
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            includeFontPadding = false
            setPadding(0, 0, 0, 0)
            background = makeKeyBackground(suggestionBg)
            stateListAnimator = null
            isFocusable = false
            isSoundEffectsEnabled = false
            setOnClickListener { showModeSelector() }
        }
        suggestions.addView(button, LinearLayout.LayoutParams(dp(42), -1).apply {
            setMargins(dp(2), dp(1), dp(2), dp(1))
        })
    }

    private fun renderEmojiStrip() {
        if (!::suggestions.isInitialized) return
        suggestions.removeAllViews()
        val emojis = listOf("▦", "😀", "😄", "😁", "😂", "🤣")
        emojis.forEachIndexed { index, value ->
            val b = Button(this).apply {
                text = value
                textSize = if (index == 0) 18f else 17f
                isAllCaps = false
                setTextColor(keyText)
                minHeight = 0
                minimumHeight = 0
                minWidth = 0
                minimumWidth = 0
                includeFontPadding = false
                setPadding(0, 0, 0, 0)
                background = makeKeyBackground(suggestionBg)
                stateListAnimator = null
                setOnClickListener {
                    if (value == "▦") showModeSelector()
                    else {
                        safeCommit(value)
                    }
                }
            }
            suggestions.addView(b, LinearLayout.LayoutParams(0, -1, 1f).apply {
                setMargins(dp(2), dp(1), dp(2), dp(1))
            })
        }
        if (symbols) {
            addDateTimeButton("📅 Date") { safeCommit(SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())) }
            addDateTimeButton("🕒 Time") { safeCommit(SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())) }
        }
    }

    private fun addDateTimeButton(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setTextColor(keyText)
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            includeFontPadding = false
            setPadding(dp(3), 0, dp(3), 0)
            background = makeKeyBackground(suggestionBg)
            stateListAnimator = null
            isFocusable = false
            isSoundEffectsEnabled = false
            setOnClickListener { action() }
        }
        suggestions.addView(b, LinearLayout.LayoutParams(0, -1, 1.35f).apply {
            setMargins(dp(2), dp(1), dp(2), dp(1))
        })
    }

    private fun updateSuggestions() {
        // Keep the emoji/date strip stable while typing. Recreating all
        // buttons after every character causes visible lag and dropped taps.
        // The strip is rebuilt only when switching ABC/123 or opening modes.
    }

    private fun suggest(value: String, replaceAll: Boolean = false) {
        val button = Button(this).apply {
            text = value
            textSize = 15f
            isAllCaps = false
            setTextColor(keyText)
            minHeight = 0
            minimumHeight = 0
            minWidth = 0
            minimumWidth = 0
            includeFontPadding = false
            setPadding(dp(4), 0, dp(4), 0)
            background = makeKeyBackground(suggestionBg)
            stateListAnimator = null
            isFocusable = false
            isSoundEffectsEnabled = false
            setOnClickListener {
                try {
                    val all = editorText()
                    val count = if (replaceAll) all.length else token(all).length
                    if (count > 0) safeDelete(count)
                    safeCommit(value)
                    updateSuggestions()
                } catch (_: Exception) { }
            }
        }
        suggestions.addView(button, LinearLayout.LayoutParams(0, -1, 1f).apply {
            setMargins(dp(2), dp(1), dp(2), dp(1))
        })
    }

    override fun onDestroy() {
        backspaceHandler.removeCallbacksAndMessages(null)
        backspaceDeleting = false
        backspaceBurstStarted = false
        super.onDestroy()
    }
}
